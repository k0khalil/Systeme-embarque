#include "mainwindow.h"
#include "ui_mainwindow.h"
//#include <QtXml>
//#include <QDomDocument>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //this->showFullScreen();
    ui->stackedWidget->setCurrentWidget(ui->page_main_1);
    QPixmap pic(":/resources/LOGO_ENIB.png");
    ui->label_Logo->setPixmap(pic);
    ui->label_Logo->setPixmap(pic.scaled(200,500,Qt::KeepAspectRatio));
    usbDevice = new QSerialPort(this);

    connect(usbDevice,SIGNAL(readyRead()),this,SLOT(onSerialDataAvailable()));


    baudrate = QSerialPort::Baud115200;

    ui->customPlot_Acce->addGraph();
    ui->customPlot_Acce->graph(0)->setPen(QPen(Qt::blue)); // line color blue for first graph
    ui->customPlot_Acce->graph(0)->setBrush(QBrush(QColor(0, 0, 255, 20))); // first graph will be filled with translucent blue

    ui->tableWidget->setRowCount(25);
    ui->tableWidget->setColumnCount(10);


    serialDeviceIsConnected = false;
    getAvalilableSerialDevices();
}

MainWindow::~MainWindow()
{
    delete ui;
    delete usbDevice;
}


//***********************************Graphique test******************************************************

void MainWindow::compute_ACC()
{
    counterA ++;
    plot_ACC();
}

void MainWindow::AddPoint_ACC(double x, double y)
{

    qv_x.append(x);
    qv_y.append(y);

}

void MainWindow::plot_ACC()
{
     ui->customPlot_Acce->graph(0)->setData(qv_x,qv_y);
     ui->customPlot_Acce->xAxis2->setVisible(true);
     ui->customPlot_Acce->xAxis2->setTickLabels(false);
     ui->customPlot_Acce->yAxis2->setVisible(true);
     ui->customPlot_Acce->yAxis2->setTickLabels(false);
     ui->customPlot_Acce->replot();
     ui->customPlot_Acce->update();
     ui->customPlot_Acce->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom | QCP::iSelectPlottables);
}


//******************************************************************************************************


void MainWindow::getAvalilableSerialDevices()
{
    qDebug() << "Number of available ports: " << QSerialPortInfo::availablePorts().length();
    serialComPortList.clear();
    ui->serialPortSelect_comboBox->clear();
    foreach(const QSerialPortInfo &serialPortInfo, QSerialPortInfo::availablePorts())
    {
        QString dbgStr = "Vendor ID: ";


       if(serialPortInfo.hasVendorIdentifier())
       {
          dbgStr+= serialPortInfo.vendorIdentifier();
       }
       else
       {
          dbgStr+= " - ";
       }
       dbgStr+= "  Product ID: ";
       if(serialPortInfo.hasProductIdentifier())
       {
          dbgStr+= serialPortInfo.hasProductIdentifier();
       }
       else
       {
          dbgStr+= " - ";
       }
       dbgStr+= " Name: " + serialPortInfo.portName();
       dbgStr+= " Description: "+serialPortInfo.description();
      qDebug()<<dbgStr;
      serialComPortList.push_back(serialPortInfo);
      ui->serialPortSelect_comboBox->addItem(serialPortInfo.portName() +" "+serialPortInfo.description());
    }
}
//******************************************************************************************************
void MainWindow::serialWrite(QString message)
{
    if(serialDeviceIsConnected == true)
    {
        usbDevice->write(message.toUtf8()); // Send the message to the device
        qDebug() << "Message to device: "<<message;
    }
}
//******************************************************************************************************
void MainWindow::serialRead()
{
    if(serialDeviceIsConnected == true)
    {
        serialBuffer += usbDevice->readAll(); // Read the available data
        data = usbDevice->readAll();

    }

}
//******************************************************************************************************
void MainWindow::onSerialDataAvailable()
{
    if(serialDeviceIsConnected == true)
    {
        serialRead(); // Read a chunk of the Message
        //To solve that problem I send a end char "]" in My case. That helped my to know when a message is complete

        if(serialBuffer.indexOf(".") != -1) //Message complete
        {
            qDebug() << "Message from device: "<<serialBuffer;

            if (serialBuffer[0]!="G")
            {
            ui->textBrowser_Data->setText(serialBuffer);
            ui->textBrowser_Data->setAlignment(Qt::AlignCenter);
            }

            int indice=0;
            QString data1;

           if (serialBuffer[0]=="P")
           {
           while(serialBuffer[indice] != ".")
           {
               data1[indice]=serialBuffer[indice+1];
               indice ++;
           }
           indice=0;
           QString data3;

           while(serialBuffer[indice] != ".")
           {
               data3[indice]=data1[indice];
               indice ++;
           }
           qDebug() <<"333333"<<data3;
           double data2= data3.toDouble();
           qDebug() <<"222222"<<data2;
           qDebug() <<"counter"<<counterA;
           AddPoint_ACC(counterA,data2);
           compute_ACC();
           indice=0;
           auto data4= new QTableWidgetItem(data3);
           ui->tableWidget->setItem(h, 0, data4);
           h++;
           }

            serialWrite("echoFromGui");

            //Do something with de message here

            serialBuffer = "";  //Clear the buffer;
        }


    }
}

//******************************************************************************************************
void MainWindow::on_connect_button_clicked()
{
    if(serialDeviceIsConnected == false)
    {
        usbDevice->setPortName(serialComPortList[ui->serialPortSelect_comboBox->currentIndex()].portName());
        deviceDescription = serialComPortList[ui->serialPortSelect_comboBox->currentIndex()].description();
        qDebug() << "connecting to: "<<usbDevice->portName();
        if(usbDevice->open(QIODevice::ReadWrite))
        {
            //Now the serial port is open try to set configuration
            if(!usbDevice->setBaudRate(baudrate))        //Depends on your boud-rate on the Device
                qDebug()<<usbDevice->errorString();

            if(!usbDevice->setDataBits(QSerialPort::Data8))
                qDebug()<<usbDevice->errorString();

            if(!usbDevice->setParity(QSerialPort::NoParity))
                qDebug()<<usbDevice->errorString();

            if(!usbDevice->setStopBits(QSerialPort::OneStop))
                qDebug()<<usbDevice->errorString();

            if(!usbDevice->setFlowControl(QSerialPort::NoFlowControl))
                qDebug()<<usbDevice->errorString();

            //If any error was returned the serial il corrctly configured

            qDebug() << "Connection to: "<< usbDevice->portName() << " " << deviceDescription << " connected";
            serialDeviceIsConnected = true;
        }
        else
        {
            qDebug() << "Connection to: "<< usbDevice->portName() << " " << deviceDescription << " not connected";
            qDebug() <<"         Error: "<<usbDevice->errorString();
            serialDeviceIsConnected = false;
        }
    }
    else
    {
        qDebug() << "Can't connect, another device is connected";
    }
}
//******************************************************************************************************

void MainWindow::on_pushButton_Exit_clicked()
{
    qApp->closeAllWindows();
}

void MainWindow::on_pushButton_Retour1_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->page_main_1);
}

void MainWindow::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->page_main_1);
}

void MainWindow::on_pushButton_retour2_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->page_main_1);
}

void MainWindow::on_disconnect_clicked()
{
    if(serialDeviceIsConnected)
    {
        usbDevice->close();
        serialDeviceIsConnected = false;
        qDebug() << "Connection to: "<< usbDevice->portName() << " " << deviceDescription << " closed";
   }
    else
    {
      qDebug() << "Can't disconnect, no device is connected";
    }
}

void MainWindow::on_pushButton_Graphe_clicked()
{
     ui->stackedWidget->setCurrentWidget(ui->page_acc);
}

void MainWindow::on_pushButton_Up_clicked()
{
    QString message;
    message='Z';
    serialWrite(message);
}

void MainWindow::on_pushButton_down_clicked()
{
    QString message;
    message='S';
    serialWrite(message);
}

void MainWindow::on_pushButton_left_clicked()
{
    QString message;
    message='Q';
    serialWrite(message);
}

void MainWindow::on_pushButton_right_clicked()
{
    QString message;
    message='D';
    serialWrite(message);
}

void MainWindow::on_pushButton_send_clicked()
{
    QString message=ui->mes_to_send->text();
    serialWrite(message);
    qDebug()<<"message"<<message;
}

void MainWindow::on_pushButton_Donnees_clicked()
{
    ui->stackedWidget->setCurrentWidget(ui->page_pot);


}

void MainWindow::on_pushButton_savexml_clicked()
{
    QString filename = QFileDialog::getSaveFileName(this,
                                           tr("Save Xml"), ".",
                                           tr("Xml files (*.xml)"));
    QFile file(filename);
    file.open(QIODevice::WriteOnly);

    QXmlStreamWriter xmlWriter(&file);
    xmlWriter.setAutoFormatting(true);
    xmlWriter.writeStartDocument();
    int k=0;
    xmlWriter.writeStartElement("Y");
    while(k<=25)
    {

    QString data =ui->tableWidget->model()->index(k,0).data().toString();

    xmlWriter.writeTextElement("y", data );
    k++;
    }


    xmlWriter.writeEndElement();

        file.close();
}

void MainWindow::on_pushButton_Open_clicked()
{
    QXmlStreamReader Rxml;

    QString filename = QFileDialog::getOpenFileName(this,
                               tr("Open Xml"), ".",
                               tr("Xml files (*.xml)"));

QFile file(filename);
    if (!file.open(QFile::ReadOnly | QFile::Text))
{
  qDebug("cannot open");

}

Rxml.setDevice(&file);
Rxml.readNext();
int v=0;

            while(!Rxml.atEnd())
                        {
                         if(Rxml.name() == "y")
                         {

                             qDebug("abc");
                                     QString roomelement = Rxml.readElementText();   //Get the xml value
                                     auto data4= new QTableWidgetItem(roomelement);
                                     ui->tableWidget->setItem(v, 0, data4);
                                     v++;



                         }

                     }

file.close();
//}
}
