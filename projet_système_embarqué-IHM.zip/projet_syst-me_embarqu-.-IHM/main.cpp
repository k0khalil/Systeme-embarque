#include "mainwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    a.setApplicationName("ENIB");
    a.setApplicationDisplayName("ENIB-Projet_Emb_Team06");
    a.setStyle("Fusion");
    a.setWindowIcon(QIcon(":/resources/Logo_ENIB_2012.png"));
    w.show();

    return a.exec();
}
