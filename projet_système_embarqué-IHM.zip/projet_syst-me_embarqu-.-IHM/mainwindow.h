#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QtSerialPort>
#include <QSerialPortInfo>
#include <QDebug>
#include <vector>


namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
        Q_OBJECT

    public:
        explicit MainWindow(QWidget *parent = 0);
        ~MainWindow();


    private slots:
        void onSerialDataAvailable();
        void on_connect_button_clicked();

      //  void on_pushButton_Acc_clicked();

       // void on_pushButton_Encodeur_clicked();

        //void on_pushButton_Potentiometre_clicked();

        void on_pushButton_Exit_clicked();

        void on_pushButton_Retour1_clicked();

        void on_pushButton_clicked();

        void on_pushButton_retour2_clicked();

        void on_disconnect_clicked();

        void on_pushButton_Graphe_clicked();

        void on_pushButton_Up_clicked();

        void on_pushButton_down_clicked();

        void on_pushButton_left_clicked();

        void on_pushButton_right_clicked();

        void on_pushButton_send_clicked();

        void on_pushButton_Donnees_clicked();

        void on_pushButton_savexml_clicked();

        void on_pushButton_Open_clicked();

private:

        Ui::MainWindow *ui;
        qint32 baudrate;
        QSerialPort *usbDevice;
        std::vector<QSerialPortInfo> serialComPortList; //A list of the available ports for the dropdownmenue in the GUI
        QString deviceDescription;
        QString serialBuffer;
        QByteArray data="";

        int i =0;
        int h=0;

        int counterA =0;

        QVector<double> qv_x,qv_y;



        bool serialDeviceIsConnected;

private:
        void compute_ACC();
        void AddPoint_ACC(double x , double y);
        void plot_ACC();


        void getAvalilableSerialDevices();
        void serialRead();
        void serialWrite(QString message);

};

#endif // MAINWINDOW_H
