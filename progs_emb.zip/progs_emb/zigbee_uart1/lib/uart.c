#include <stdlib.h>
#include <stdarg.h>
#include "uart.h"
#include "io.h"
#include "util.h"

// USART Pin config
#define USART_PIN_CONFIG_TX	(PIN_MODE_ALTFUNC | PIN_OPT_OUTPUT_PUSHPULL | PIN_OPT_OUTPUT_SPEED_LOW | PIN_OPT_RESISTOR_NONE | PIN_OPT_AF7)
                             
#define USART_PIN_CONFIG_RX	(PIN_MODE_ALTFUNC | PIN_MODE_INPUT | PIN_OPT_RESISTOR_NONE | PIN_OPT_AF7)

#define USART_PIN_CONFIG 	(PIN_MODE_ALTFUNC|PIN_OPT_OUTPUT_PUSHPULL|PIN_OPT_OUTPUT_SPEED_LOW|PIN_OPT_RESISTOR_NONE|PIN_OPT_AF7)

                             
#ifdef USE_USART1
static OnUartRx usart1_cb = 0;

void USART1_IRQHandler()
{
	uint32_t sr = _USART1->SR;
	
	if (sr & (1<<5)) {			// Read data register not empty interrupt
		if (!((sr & (1<<1)) || (sr & (1<<2)))) {
			if (usart1_cb) usart1_cb(_USART1->DR);
		} else {				// Noise or framing error or break detected
			_USART1->DR;
		}
	} else if (sr & (1<<4)) {	// idle interrupt
		_USART1->DR;
	} else if (sr & (1<<3)) {	// overrun interrupt
		_USART1->DR;
	} else if (sr & (1<<0)) {	// parity error interrupt
		_USART1->DR;
	}
}
#endif

#ifdef USE_USART2
static OnUartRx usart2_cb = 0;

void USART2_IRQHandler()
{
	uint32_t sr = _USART2->SR;
	
	if (sr & (1<<5)) {			// Read data register not empty interrupt
		if (!((sr & (1<<1)) || (sr & (1<<2)))) {
			if (usart2_cb) usart2_cb(_USART2->DR);
		} else {				// Noise or framing error or break detected
			_USART2->DR;
		}
	} else if (sr & (1<<4)) {	// idle interrupt
		_USART2->DR;
	} else if (sr & (1<<3)) {	// overrun interrupt
		_USART2->DR;
	} else if (sr & (1<<0)) {	// parity error interrupt
		_USART2->DR;
	}
}
#endif

#ifdef USE_USART6
static OnUartRx usart6_cb = 0;

void USART6_IRQHandler()
{
	uint32_t sr = _USART6->SR;
	
	if (sr & (1<<5)) {			// Read data register not empty interrupt
		if (!((sr & (1<<1)) || (sr & (1<<2)))) {
			if (usart6_cb) usart6_cb(_USART6->DR);
		} else {				// Noise or framing error or break detected
			_USART6->DR;
		}
	} else if (sr & (1<<4)) {	// idle interrupt
		_USART6->DR;
	} else if (sr & (1<<3)) {	// overrun interrupt
		_USART6->DR;
	} else if (sr & (1<<0)) {	// parity error interrupt
		_USART6->DR;
	}
}
#endif



/*
 * uart_init : polling Tx and IRQ Rx
 */
int uart_init(USART_t *u, uint32_t baud, uint32_t mode, OnUartRx cb)
{
	IRQn_t	irq_number;
	uint32_t irq_priority;
	
	if (u == _USART1) {
#ifdef USE_USART1
		// enable USART clocking
		_RCC->APB2ENR |= 1<<4;
		
		// configure Tx/Rx pins : Tx -->, Rx --> 
		io_configure(USART1_GPIO_PORT, USART1_GPIO_PINS, USART_PIN_CONFIG, NULL);

        //baud rate
        u->BRR = (sysclks.apb1_freq / baud); 

        //interdire les interruptions
       	u->CR1 &= ~(1<<5);
       	usart1_cb=cb;
       	irq_number=37;
       	irq_priority=44;


#else
		return -1;
#endif
	 } else if (u == _USART2) {
#ifdef USE_USART2
		// enable USART clocking
		_RCC->APB1ENR |= 1<<17;
	
		// configure Tx/Rx pins : Tx --> PA2, Rx --> PA3
		io_configure(USART2_GPIO_PORT, PIN_2, USART_PIN_CONFIG_RX, NULL);
		io_configure(USART2_GPIO_PORT, PIN_3, USART_PIN_CONFIG_TX, NULL);
		
        //baud rate
       	u->BRR = (sysclks.apb1_freq / baud);
       
          //interdire les interruptions
       	u->CR1 &= ~(1<<5);
 		usart2_cb=cb;
       	irq_number=38;
       	irq_priority=45;

#else
		return -1;
#endif
	} else if (u == _USART6) {
#ifdef USE_USART6
		// enable USART clocking
		_RCC->APB2ENR |= 1<<5;

		// configure Tx/Rx pins
		io_configure(USART6_GPIO_PORT, PIN_11, USART_PIN_CONFIG_RX, NULL);
		io_configure(USART6_GPIO_PORT, PIN_12, USART_PIN_CONFIG_TX, NULL);

        //baud rate
       	u->BRR = (sysclks.apb1_freq / baud);

       	 //interdire les interruptions
        u->CR1 &= ~(1<<5);
       	usart6_cb=cb;
       	irq_number=71;
       	irq_priority=78;

#else
		return -1;
#endif
	} else {
		return -1;
	}
	
	//USART configuration	

    u->CR1 |= (1<<13); //usart enable
    u->CR1 |= (1<<2);  // receiver enable 2
    u->CR1 |= (1<<3);  //Transmitter enable 3 
    u->CR1 |= ((mode & (3<<8)) <<8); //PE interrupt enable  Parity selection Parity control enable

    u->CR2 |= ((mode & (2<<4)) <<12); //STOP bits
	
			 

	    
	   
	if (cb) {	
	// Setup NVIC 
	// Receiver Not Empty Interrupt Enable
	   u->CR1 |= (1<<5);
	   NVIC_SetPriority(irq_number, irq_priority);
	   NVIC_EnableIRQ(irq_number);
	    
	}

    return 1;
}

/*
 * uart_getc : get a char from the serial link (blocking)
 */
char uart_getc(USART_t *u)
{
	//while the data register is empty, hold !

	while((u->SR & 1<<5) == 0){}
		return (char) u->DR ;
	 
}

/*
 * uart_putc : send a char over the serial link (polling)
 */
void uart_putc(USART_t *u, char c)
{
	//tant que les données n'est pas transferer, attendre
  	//while the data isn't transfered, hold !

  	while ((u->SR & (1<<7)) == 0){}	;	// wait for Data Register empty
	
	 u->DR = c;	 //put the data in the DR register
}

/*
 * uart_puts : send a string over the serial link (polling)
 */
void uart_puts(USART_t *u, char *s)
{
      //while we arn't at the end of the string, send char, and increment the pointer
   

	 while (*s != '\0') {
		uart_putc(u,*s);
		s++;
	}
}

/*
 * uart_printf : print formatted text to serial link
 */
void uart_printf(USART_t * u, const char* fmt, ...)
{
    __gnuc_va_list        ap;
    char          *p;
    char           ch;
    unsigned long  ul;
    char           s[34];
     
    va_start(ap, fmt);
    while (*fmt != '\0') {
        if (*fmt =='%') {
            switch (*++fmt) {
                case '%':
                    uart_putc(u,'%');
                    break;
                case 'c':
                    ch = va_arg(ap, int);
                    uart_putc(u, ch);
                    break;
                case 's':
                    p = va_arg(ap, char *);
                    uart_puts(u, p);
                    break;
                case 'd':
                    ul = va_arg(ap, long);
                    if ((long)ul < 0) {
                        uart_putc(u, '-');
                        ul = -(long)ul;
                    }
                    num2str(s, ul, 10);
                    uart_puts(u, s);
                    break;
                case 'u':
                    ul = va_arg(ap, unsigned int);
                    num2str(s, ul, 10);
                    uart_puts(u, s);
                    break;
                case 'x':
                    ul = va_arg(ap, unsigned int);
                    num2str(s, ul, 16);
                    uart_puts(u, s);
                    break;
                default:
                    uart_putc(u, *fmt);
            }
        } else uart_putc(u, *fmt);
        fmt++;
    }
    va_end(ap);
}



