#include "include/board.h"
#include "lib/io.h"
#include "lib/uart.h"
#include "lib/util.h"
#include "lib/i2c.h"
#include "libshield/lm75.h"
#include "libshield/mma7660.h"


#define MMA0
#define SAD 0x6a	
#define OUTY_L_G_REGISTER 0x24	
#define CTRL2_G 0x11



volatile char cmd;
char buf[10];


static void on_rx_cb(char c)
{
	cmd = c;
}


void delay_us(uint32_t delay_us);
void delay_ms(uint16_t delay_ms);





int32_t buffer[4], moy[4]={0,0,0,0}, tmp;
int k=0;


int main()
{
	


	
	uart_init(_USART1, 9600, UART_8N1, on_rx_cb);
	uart_init(_USART2, 9600, UART_8N1, on_rx_cb);
	
	

	int c=0;
	char c1=1;
	
	while(1) {



		
		delay_ms(500);
		
		uart_printf(_USART1,"%d",c);
		//uart_putc(_USART1,c1);
		
		
		
	}
		
		
	
	return 0;
}




//Microsecond delay
void delay_us(uint32_t delay_us)
{
  volatile unsigned int num;
  volatile unsigned int t;


  for (num = 0; num < delay_us; num++)
  {
    t = 11;
    while (t != 0)
    {
      t--;
    }
  }
}
//Millisecond delay
void delay_ms(uint16_t delay_ms)
{
  volatile unsigned int num;
  for (num = 0; num < delay_ms; num++)
  {
    delay_us(1000);
  }
}

