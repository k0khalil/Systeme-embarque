#include "include/board.h"
#include "lib/io.h"
#include "lib/uart.h"
#include "lib/util.h"
#include "lib/i2c.h"
#include "libshield/lm75.h"
#include "libshield/mma7660.h"




#define MMA0
#define SAD 0x6a	
#define OUTY_L_G_REGISTER 0x24	
#define CTRL2_G 0x11

void delay_us(uint32_t delay_us);
void delay_ms(uint16_t delay_ms);

void LSM6DS3_init();
int LSM6DS3_read_acc_X();
int LSM6DS3_read_acc_Y();
int LSM6DS3_read_acc_Z();
int LSM6DS3_read_gyro_X();

volatile char cmd;
char buf[10];


static void on_rx_cb(char c)
{
	cmd = c;
}


uint8_t send_buffer=0x28;
uint8_t send_buffer_init_G[2]={0x10,0x4e};
uint8_t send_buffer_init_reboot[2]={0x12,0x10};

uint8_t recv_buffer[2];
uint32_t nbr = 2;
uint32_t nbw = 1;
int var_debug;
double i;
double i2;



int32_t buffer[4], moy[4]={0,0,0,0}, tmp;
int k=0;


int main()
{
	


	i2c_master_init(_I2C1);
	var_debug=1;
	uart_init(_USART2, 9600, UART_8N1, on_rx_cb);
	mma7660_setup(MMA7660_AM16|MMA7660_ACTIVE);
	
	LSM6DS3_init();
	

	
			/*switch(var_debug){
			
			case 0:
				uart_printf(_USART2,"ok       ");
				break;
				
			case 1:
				uart_printf(_USART2,"transfer busy");
				break;
				
			case -1:
				uart_printf(_USART2,"general error ");
				break;
				
			case -5:
				uart_printf(_USART2,"device not present");
				break;
				
			case -6:
				uart_printf(_USART2,"arbitration lost");
				break;
				
			case -7:
				uart_printf(_USART2,"time out");
				break;
				
			case -8:
				uart_printf(_USART2,"slave mode error ");
				break;
				
			}	*/
	
	
	while(1) {

		int accel_x;
		int accel_y;
		int accel_z;
		int angle_x;



		accel_x = LSM6DS3_read_acc_X();
		accel_y = LSM6DS3_read_acc_Y();
		accel_z = LSM6DS3_read_acc_Z();
		angle_x = LSM6DS3_read_gyro_X();
		
		
		/*uart_printf(_USART2,"accel_X : %d          ",accel_x);

		uart_printf(_USART2,"angle_X : %d    \r\n",angle_x);*/
		
		delay_ms(150);
	}
		
	
	return 0;
}



void LSM6DS3_init(){
	
	int var_debug = 0;
	
	uint8_t send_buffer_init_18[2]={0x18,0x3c};
	
	var_debug = i2c_write(_I2C1,SAD, send_buffer_init_18, 2);	
	
	
	uint8_t send_buffer_init_19[2]={0x19,0x3c};
	
	var_debug = i2c_write(_I2C1,SAD, send_buffer_init_19, 2);	
	
	
	uint8_t send_buffer_init_A[2]={0x10,0x8e};
	
	var_debug = i2c_write(_I2C1,SAD, send_buffer_init_A, 2);
	
	
	
	uint8_t send_buffer_init_G[2]={0x11,0x8e};
	
	var_debug = i2c_write(_I2C1,SAD, send_buffer_init_G, 2);
}


int LSM6DS3_read_acc_X(){
	
	int var_debug = 0;
	uint8_t send_buffer=0x28;
	int8_t recv_buffer[2];
		
	var_debug = i2c_write(_I2C1,0x6a, &send_buffer, 1);			

	var_debug = i2c_read(_I2C1,0x6a, recv_buffer, 2);
	
	int return_value = ((int)recv_buffer[0] << 8) | recv_buffer[1];
	
	
	return return_value;
}

int LSM6DS3_read_acc_Y(){
	
	int var_debug = 0;
	uint8_t send_buffer=0x2a;
	uint8_t recv_buffer[2];
		
	var_debug = i2c_write(_I2C1,0x6a, &send_buffer, 1);			

	var_debug = i2c_read(_I2C1,0x6a, recv_buffer, 2);
	
	int return_value = ((int)recv_buffer[0] << 8) | recv_buffer[1];
	
	return return_value;
}

int LSM6DS3_read_acc_Z(){
	
	int var_debug = 0;
	uint8_t send_buffer=0x2c;
	uint8_t recv_buffer[2];
		
	var_debug = i2c_write(_I2C1,0x6a, &send_buffer, 1);			

	var_debug = i2c_read(_I2C1,0x6a, recv_buffer, 2);
	
	int return_value = ((int)recv_buffer[0] << 8) | recv_buffer[1];
	
	return return_value;
}

int LSM6DS3_read_gyro_X(){
	

	int var_debug = 0;
	uint8_t send_buffer=0x23;
	uint8_t recv_buffer[2];
		
	var_debug = i2c_write(_I2C1,0x6a, &send_buffer, 1);			

	var_debug = i2c_read(_I2C1,0x6a, recv_buffer, 2);
	
	

	int return_value = ((int)recv_buffer[0] << 8) | recv_buffer[1];
	
	uart_printf(_USART2,"[0] : %d          ",recv_buffer[0]);
	uart_printf(_USART2,"[1] : %d          \r\n",recv_buffer[1]);
	
	return return_value;
}


//Microsecond delay
void delay_us(uint32_t delay_us)
{
  volatile unsigned int num;
  volatile unsigned int t;


  for (num = 0; num < delay_us; num++)
  {
    t = 11;
    while (t != 0)
    {
      t--;
    }
  }
}
//Millisecond delay
void delay_ms(uint16_t delay_ms)
{
  volatile unsigned int num;
  for (num = 0; num < delay_ms; num++)
  {
    delay_us(1000);
  }
}
