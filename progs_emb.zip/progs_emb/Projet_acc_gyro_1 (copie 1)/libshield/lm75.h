#ifndef _LM75_H_
#define _LM75_H_

/* lm75_read_temp
 *   get current measured temperature
 */
int  lm75_read_temp(int *temp);

#endif
